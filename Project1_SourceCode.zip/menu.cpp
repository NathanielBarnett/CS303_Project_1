//Students : Nathaniel Barnett    | Adam Bergman         | Urvish Shah
//Email    : nabgz8@mail.umkc.edu | ambd5d@mail.umkc.edu | ujs8t2@mail.umkc.edu

//Professor: Dr. Mohammad Kuhail
//Class    : CS 303 - Data Structures 

//Date     : 9/25/2016
//Project  : Polynomial Addition Program (Project 1B)

//File name:menu.cpp
#include "menu.h"
#include "polynomial.h"
#include "term.h"
#include <iomanip>

void Menu::GetUserInput()
{
	string polynomial1, polynomial2;
	string valid_chars = "0123456789+-^Xx";

	//read first poly
	cout << "\nPlease enter your first polynomial: ";
	getline(cin, polynomial1);

	//ensure that user has entered a valid Polynomial
	while(polynomial1.find_first_not_of(valid_chars) != -1)
	{
		cout << "\nPlease enter your first polynomial: ";
		getline(cin, polynomial1);
	}

	//parse user input and convert to Term object and push onto Polynomial
	Poly_Parse(polynomial1, user_poly);

	//read second poly
	cout << "\nPlease enter your second polynomial: ";
	getline(cin, polynomial2);

	//ensure tha tuser hasentered a valid polynomial
	while (polynomial2.find_first_not_of(valid_chars) != -1)
	{
		cout << "\nPlease enter your second polynomial: ";
		getline(cin, polynomial2);
	}

	//parse user input and convert to Term object and push onto Polynomial
	Poly_Parse(polynomial2, user_poly);

	//Print the resultant Polynomial
	user_poly.Pretty_Print(polynomial1, polynomial2);
	user_poly.Poly_Print();

	//clear the Polynomial object
	user_poly.Clear_Poly();
}

void Menu::ShowMenu()
{
	cout << "********** -Polynomial Addition Program- **********" << endl;
	cout << "\nRules:\n";
	cout << "You can enter your polynomial in the follwing format : ax^n+ax-1" << endl;
	cout << "Considering a = coefficient, x = variable and n = whole number" << endl;
	cout << "Please do not use paranthesis or spaces." << endl;
	cout << "You can enter either the + or - operator based on your choice for the polynomial" << endl;
	cout << endl;

	char input;
	bool end = true;
	while (end != false)
	{
		cout << "\nPlease choose one of the following option:\n";
		cout << "<E> to enter a Polynomial\n<N> to quit the program\n";
		cout << "Please enter <E> or <N>:" << endl;

		cin >> input;
		cin.ignore(256, '\n');

		switch (input)
		{
		case 'E':
		case 'e':
			//call function to let the user enter polynomials
			GetUserInput();
			break;

		case 'N':
		case'n':
			//terminate program 
			end = false;
			exit(0);


		default:
			cout << "\nPlease enter 'E' or 'N'" << endl;
		}
	}
}

