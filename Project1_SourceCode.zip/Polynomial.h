//Students : Nathaniel Barnett    | Adam Bergman         | Urvish Shah
//Email    : nabgz8@mail.umkc.edu | ambd5d@mail.umkc.edu | ujs8t2@mail.umkc.edu

//Professor: Dr. Mohammad Kuhail
//Class    : CS 303 - Data Structures 

//Date     : 9/25/2016
//Project  : Polynomial Addition Program (Project 1B)

//File name:Polynomial.h
#pragma once
#include <list>
#include <iostream>
#include <string>
#include "Term.h"
using namespace std;

class Polynomial {

private:
	list<Term> L_Poly;

public:
	Polynomial() { ; }

	void Clear_Poly() { L_Poly.clear(); }
	
	const Polynomial operator+(const Polynomial& rhs_Poly);//Adds polynomials 

	void Pretty_Print(const string& Poly1, const string& Poly2);
	void Poly_Print();//printing polynomial

	void AddTerm(string S_Term);//function to add Term element onto polynomial list

};

// Utility function for polynomial class
void Poly_Parse(const string& s, Polynomial& Poly, const string& delim = "-+");
